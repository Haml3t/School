/**
 * Created by nooreddin on 3/29/16.
 */

//package finalproject;

public class TestAI_Project
{
    public static void main(String[] args)
    {
	Environment.getInstance().startEarth(200);
    }

}
