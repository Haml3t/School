/**
 * Created by nooreddin on 4/5/16.
 */


public class Plant extends NonLocomotiveAgent {

     public Plant(int x, int y, Environment env) {
          super(x, y, env);
     }

}
