/**
 * Created by nooreddin on 4/7/16.
 */
public interface MoveState {
}
